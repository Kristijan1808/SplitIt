import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, FolderOpen } from "lucide-react";
import { ThemeToggle } from "../components/ThemeToggle";
import { useLanguage } from "../i18n";
import { getSavedGroups, type SavedGroup } from "../storage";

export function MyGroupsPage() {
  const { t } = useLanguage();
  const [groups, setGroups] = useState<SavedGroup[]>([]);

  useEffect(() => {
    // "My groups" is deliberately local-first. We do not ask the API
    // which groups belong to this browser.
    setGroups(getSavedGroups());
  }, []);

  return (
    <main className="page">
      <div className="topBar">
        <ThemeToggle />
      </div>

      <Link className="backLink" to="/">
        <ArrowLeft size={18} /> {t("home")}
      </Link>

      <section className="card">
        <h1>{t("myGroups")}</h1>

        {groups.length === 0 ? (
          <p className="muted">{t("noSavedGroups")}</p>
        ) : (
          <div className="list">
            {groups.map((group) => (
              <Link
                className="groupRow"
                key={group.slug}
                to={`/g/${group.slug}`}
              >
                <div style={{ minWidth: 0 }}>
                  <strong>{group.name}</strong>
                  {group.code && (
                    <small className="muted" style={{ display: "block" }}>
                      {t("code")}: {group.code}
                    </small>
                  )}
                  {group.participantName && (
                    <small className="muted" style={{ display: "block" }}>
                      {t("youAre")}: {group.participantName}
                    </small>
                  )}
                </div>

                <small className="inlineFlex">
                  <FolderOpen size={15} /> {t("open")}
                </small>
              </Link>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
